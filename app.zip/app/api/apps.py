from django.apps import AppConfig


class APIConfig(AppConfig):
    name = 'api'
